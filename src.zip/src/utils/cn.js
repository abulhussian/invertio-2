import { clsx } from "clsx"

export function cn(...inputs) {
  return clsx(inputs)
}
